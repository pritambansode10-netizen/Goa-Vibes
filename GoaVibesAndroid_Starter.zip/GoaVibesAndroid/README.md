# Goa Vibes - Android starter app

This is a native Android starter project written in Kotlin + Jetpack Compose.

## Included in version 1
- Goa-themed Explore screen with sample destinations
- North Goa / South Goa starter itinerary
- Editable group budget calculator
- Save/favourite places locally while the app is open

## Build an APK without installing Android Studio (GitHub Actions)
1. Sign in to GitHub and create a **new public or private repository** named `GoaVibes`.
2. On the repository page, choose **Add file > Upload files** and upload the contents of this project folder (including the hidden `.github` folder). Commit the upload to the `main` branch.
3. Open the repository's **Actions** tab. The workflow named **Build Goa Vibes APK** should start automatically after the commit. If it does not, open that workflow and choose **Run workflow**.
4. When the run finishes successfully, open that run and download the **Goa-Vibes-debug-APK** artifact.
5. Extract the downloaded ZIP on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/file manager.

## Important
This is a starter prototype, not a Play Store-ready release. It currently uses sample destination content and does not yet include live maps, booking integrations, user accounts, cloud sync, reviews, or a backend. The debug APK is for testing; a Play Store release needs a properly signed release build and privacy/data-safety work.
