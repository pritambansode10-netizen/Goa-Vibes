package com.goavibes.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ocean = Color(0xFF087E8B)
private val Deep = Color(0xFF064B59)
private val Sand = Color(0xFFFFF7E8)
private val Coral = Color(0xFFFF765E)

data class Place(val name: String, val area: String, val type: String, val emoji: String, val note: String)

private val places = listOf(
    Place("Baga Beach", "North Goa", "Beach", "🏖️", "Beach shacks, water sports and lively evenings"),
    Place("Calangute Beach", "North Goa", "Beach", "🌊", "A classic long beach for a first Goa visit"),
    Place("Fort Aguada", "North Goa", "Heritage", "🏰", "Sea views, history and beautiful photo spots"),
    Place("Chapora Fort", "North Goa", "Viewpoint", "🌅", "A memorable sunset viewpoint"),
    Place("Palolem Beach", "South Goa", "Beach", "🌴", "A quieter crescent-shaped beach"),
    Place("Dudhsagar Falls", "South Goa", "Nature", "💦", "A dramatic waterfall surrounded by greenery")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoaVibesApp() }
    }
}

@Composable
fun GoaVibesApp() {
    var tab by remember { mutableStateOf(0) }
    var saved by remember { mutableStateOf(setOf<String>()) }
    var people by remember { mutableStateOf("4") }
    var days by remember { mutableStateOf("3") }
    var daily by remember { mutableStateOf("2500") }
    val total = ((people.toIntOrNull() ?: 0) * (days.toIntOrNull() ?: 0) * (daily.toIntOrNull() ?: 0))
    MaterialTheme(colorScheme = lightColorScheme(primary = Ocean, secondary = Coral, background = Sand)) {
        Scaffold(
            containerColor = Sand,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Explore") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Map, null) }, label = { Text("Planner") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Calculate, null) }, label = { Text("Budget") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Saved") })
                }
            }
        ) { pad ->
            when (tab) {
                0 -> ExploreScreen(saved, { name -> saved = if (name in saved) saved - name else saved + name }, Modifier.padding(pad))
                1 -> PlannerScreen(Modifier.padding(pad))
                2 -> BudgetScreen(people, { people = it }, days, { days = it }, daily, { daily = it }, total, Modifier.padding(pad))
                else -> SavedScreen(saved, Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun ExploreScreen(saved: Set<String>, onSave: (String) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Ocean, Deep))).padding(22.dp)) {
                Column {
                    Text("GOA VIBES", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                    Text("EXPLORE  •  PLAN  •  EXPERIENCE", color = Color(0xFFD4F4F1), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(22.dp))
                    Text("Your next escape\nstarts here.", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 35.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Beaches, forts, food and unforgettable sunsets.", color = Color.White.copy(alpha = .88f))
                    Spacer(Modifier.height(18.dp))
                    Surface(color = Color.White.copy(alpha = .16f), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🌴", fontSize = 25.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("GOA TRAVEL GUIDE", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Find your kind of Goa", color = Color(0xFFD4F4F1), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
        item { Text("Popular places", Modifier.padding(start = 18.dp, top = 20.dp, bottom = 10.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Deep) }
        items(places) { place ->
            PlaceCard(place, place.name in saved) { onSave(place.name) }
        }
        item {
            Text("Travel smart", Modifier.padding(18.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Deep)
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TipCard("🧴", "Carry sunscreen")
                TipCard("💧", "Stay hydrated")
                TipCard("🛵", "Ride safely")
            }
        }
    }
}

@Composable
fun PlaceCard(place: Place, isSaved: Boolean, onSave: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(66.dp).background(Brush.linearGradient(listOf(Color(0xFFB8E8E4), Color(0xFFFFD9B8))), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                Text(place.emoji, fontSize = 30.sp)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(place.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Deep)
                Text("${place.area} • ${place.type}", color = Ocean, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text(place.note, color = Color.DarkGray, fontSize = 12.sp, lineHeight = 16.sp)
            }
            IconButton(onClick = onSave) {
                Icon(if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (isSaved) Coral else Ocean)
            }
        }
    }
}

@Composable
fun TipCard(emoji: String, label: String) {
    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Text(label, fontSize = 10.sp, color = Deep, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun PlannerScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Trip planner", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Deep)
        Text("A simple starter itinerary for your Goa escape.", color = Color.Gray)
        Spacer(Modifier.height(18.dp))
        listOf(
            Triple("DAY 1", "North Goa", "Baga Beach • Calangute • Anjuna sunset"),
            Triple("DAY 2", "Forts & local life", "Fort Aguada • Chapora Fort • local market"),
            Triple("DAY 3", "South Goa", "Palolem Beach • peaceful coastal time")
        ).forEach { item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).background(Color(0xFFD9F1EC), CircleShape), contentAlignment = Alignment.Center) {
                        Text(item.first, color = Ocean, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(item.second, fontWeight = FontWeight.Bold, color = Deep, fontSize = 17.sp)
                        Text(item.third, color = Color.DarkGray, fontSize = 13.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Tip: Travel times and opening hours should be checked before you leave.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun BudgetScreen(people: String, onPeople: (String) -> Unit, days: String, onDays: (String) -> Unit, daily: String, onDaily: (String) -> Unit, total: Int, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Budget calculator", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Deep)
        Text("Estimate a simple per-person daily budget.", color = Color.Gray)
        Spacer(Modifier.height(22.dp))
        BudgetInput("Number of travellers", people, onPeople)
        BudgetInput("Number of days", days, onDays)
        BudgetInput("Estimated spend per person / day (₹)", daily, onDaily)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Deep), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("Estimated group budget", color = Color(0xFFBFEAE4))
                Text("₹${total.coerceAtLeast(0)}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("Based on the values entered. Travel and stay costs may vary.", color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun BudgetInput(label: String, value: String, onChange: (String) -> Unit) {
    Column(Modifier.padding(bottom = 14.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold, color = Deep, fontSize = 13.sp)
        OutlinedTextField(value = value, onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(7)) }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp))
    }
}

@Composable
fun SavedScreen(saved: Set<String>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Your saved places", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Deep)
        Text("Keep your Goa shortlist in one place.", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        if (saved.isEmpty()) {
            Text("♡", fontSize = 48.sp, color = Coral)
            Text("No saved places yet. Tap the heart on any place in Explore.", color = Color.DarkGray)
        } else {
            places.filter { it.name in saved }.forEach { PlaceCard(it, true) {} }
        }
    }
}
